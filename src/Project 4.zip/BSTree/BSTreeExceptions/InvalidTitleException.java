/*
 * Project: CS2336 PROJECT 4 - Redbox Inventory System
 * Author: Jimmy Nguyen -- UTD NetID: tbn160230
 * Contact me: Jimmy@JimmyWorks.net
 */
package BSTree.BSTreeExceptions;

//==============================================================================
//                      Invalid Title Exception
//==============================================================================
//   This exception is intended to be thrown when a title is checked for validity
//   and it is improperly formatted or contains errors.
//==============================================================================  
public class InvalidTitleException extends Exception{

    public InvalidTitleException(String nodeInput) {
        
    }
    
    
}
