/*
 * Project: CS2336 PROJECT 4 - Redbox Inventory System
 * Author: Jimmy Nguyen -- UTD NetID: tbn160230
 * Contact me: Jimmy@JimmyWorks.net
 */

//==============================================================================
//                      Custom Binary Search Tree Exception
//==============================================================================
//  Extends the Exception class and also is the base class for InvalidNodeException
//  This class has not be implemented, but can be useful for future updates.
//==============================================================================
package BSTree.BSTreeExceptions;


public class BSTreeException extends Exception{
    
}
